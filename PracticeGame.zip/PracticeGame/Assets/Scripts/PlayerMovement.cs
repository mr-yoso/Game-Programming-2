using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{
    public float movementSpeed = 10f;
    private Rigidbody rb;
    private Vector3 startingPosition;
    public GameObject collectiblePrefab;

    void Start()
    {
        InvokeRepeating("SpawnCollectible", 3f, 3f);
    }

    void FixedUpdate() // Physics-related operations should go here
    {
        // Get input for horizontal and vertical axes
        float moveX = Input.GetAxis("Horizontal");
        float moveZ = Input.GetAxis("Vertical");

        Vector3 move = new Vector3(moveX, 0f, moveZ);
        transform.position += move * Time.deltaTime * 10f;


    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Collectible"))
        {
            GameManager.instance.AddScore();
            Destroy(other.gameObject);
        }
    }

    void SpawnCollectible()
    {
        Vector3 position = new Vector3(Random.Range(-25f, 25f), 0, Random.Range(-25f, 25f));
        Instantiate(collectiblePrefab, position, Quaternion.identity);
    }
}
